# plumegang
Little (early version) 2d game of a game coded in Python with Pyglet


### **DESCRIPTION**
You are a little rappeur in a new city to explore :

You begin in your own house and you need to earn money


Each day you lose some money and if you hit the 0$ bottom, this is a sad GAME OVER


In order to make money, you need to create and release 'sons' *(songs)*.

To create songs, you have to write some 'phases' *(lyrics)* in your bed with your 'plume' *(feather)*.

You also need to find an 'instru' *(instrumental)* and there you go !

**4 phases + 1 instru = 1 son**

Use the things in your house to make all this stuff !




### **FOR NOW**

For now the game is in a very early version so don't expect to see every thing right now hehe (cheh)


Stuff working :

*Lit* - long press **E** to create phase (/!\\ you need to have a plume)

*Studio* - long press **E** to assemble your song

*Plumoir* - long press **E** to get a new random plume

*Ordi* - short press **E** to earn some money *(dev hack to simplify my life -- won't work like that in the future)*




### **COMMANDS**

***Q*** - move left

***D*** - move right

***E*** - to use the things in your house (long or short press)

***ESC***  - to close the hud of the thing you are using OR to quit the game

***<-***/***->*** - to control camera

***I*** - to open/close inventory

***A*** - to drop your plume

***X*** - to hide your perso's menu

***F*** - to release the first song in your inventory (+/- working)
